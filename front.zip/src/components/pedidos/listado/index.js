import React from 'react';

function ListadoPedidos()
{
    return (
        <div>
            <table>

            </table>
        </div>
    )
}

export default ListadoPedidos